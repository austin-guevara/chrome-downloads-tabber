# chrome-downloads-tabber
Instead of opening the downloads bar, new downloads in Chrome will open 'chrome://downloads' in a new tab, or change focus to the downloads tab if one already exists.

Get this extension on the [Chrome Web Store](https://chrome.google.com/webstore/detail/download-tabber/ikifbnamadpilmpokncfbhdcbldikbdi)!

Contributions are welcome.

Thanks to [@ivan7237d](https://github.com/ivan7237d) for inspiring part of this project with [Disable Downloads Bar](https://github.com/ivan7237d/disable-downloads-bar)!
